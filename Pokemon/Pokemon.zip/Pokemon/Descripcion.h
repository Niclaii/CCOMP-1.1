#include <iostream>

std::string DBulbasaur = " Este Pok�mon nace con una semilla en el lomo, que brota con el paso del tiempo. ";
std::string DIvysaur = " Cuando le crece bastante el bulbo del lomo, pierde la capacidad de erguirse sobre las patas traseras. ";
std::string DVenusaur = " La planta florece cuando absorbe energ�a solar, lo cual le obliga a buscar siempre la luz del sol. ";
std::string DCharmander = " Prefiere las cosas calientes. Dicen que cuando llueve le sale vapor de la punta de la cola. ";
std::string DCharmeleon = " Este Pok�mon de naturaleza agresiva ataca en combate con su cola llameante y hace trizas al rival con sus afiladas garras. ";
std::string DCharizard = " Se dice que el fuego de Charizard arde con m�s fuerza cuantas m�s duras batallas haya vivido. ";
