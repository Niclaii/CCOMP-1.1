#include <iostream>
#include "cPantalla.h"


int main()
{
	Pantalla Game;
	Game.Juego();

	return 0;
}